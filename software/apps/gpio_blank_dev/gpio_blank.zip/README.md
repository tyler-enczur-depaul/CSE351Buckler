GPIO Blank
=====

This is the starting application for Chapter 4 of the lab manual. The
goal is to implement the gpio library from scratch using reads and writes
to nRF52832 registers.

# SET ON

gpio_manage->OUT |= (1 << 8);

# SET OFF

gpio_manage->OUT &= !(1 << 8);

# SET TOGGLE

gpio_manage->OUT ^= (1 << 8);
